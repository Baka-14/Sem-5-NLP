Here there are all the multiple attempts i have made at doing the nlp Assigment 

Intianlly i tried doing text summarization by using basic frequency math that you can see in Language_Modelling notebook 
Then as it didnt work out i moved on to using lstm but found seq2seq modelling bit complicated as of now 
which you can see in Text_summarization notebook
There moved to using already pretrained hugging face transformer to summarize articles from internet 
you can the url link incase you want to summarize a different article  
and now you can run this to summarize warren buffet letters using this model the dataset is present as a text file 

